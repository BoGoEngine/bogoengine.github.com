class Accents:
    1
