from bogo.bogo import *
from bogo import mark
from ibus_engine.base_config import BaseConfig
from functools import partial

c = BaseConfig("/tmp/ibus-bogo.json")
c_non_vn = BaseConfig("/tmp/ibus-bogo-non-vn.json")
c_non_vn["skip-non-vietnamese"] = True

process_key_dfl = partial(process_key, config=c)
process_key_non_vn = partial(process_key, config=c_non_vn)


def process_seq(seq, config=c):
    string = ""
    raw = string
    for i in seq:
        string, raw = process_key(string,
                                  i,
                                  fallback_sequence=raw,
                                  config=config)
    return string


process_seq_non_vn = partial(process_seq, config=c_non_vn)

# print(process_key("â", "n", "aa", config=c_non_vn))
# print(is_valid_combination(["", "â", "n"], final_form=False))

print(process_seq("tuoufw"))
print(process_seq("huoswc"))
print(process_seq("khoefo"))
print(process_seq("uowr"))
print(process_seq("uorw"))
print(mark.add_mark(['', 'uou', ''], mark.Mark.HORN))
print(process_key("ngoe", "o"))

# print(process_seq("ngoeor"))
