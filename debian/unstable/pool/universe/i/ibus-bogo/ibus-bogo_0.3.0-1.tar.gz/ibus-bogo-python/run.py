import bogo

string = "chuyener"

import time

def process_seq(seq):
    string = ""
    raw = string
    for i in seq:
        string, raw = bogo.process_key(string,
                                  i,
                                  fallback_sequence=raw)
    return string

old_time = time.time()
for word in string.split():
    print(process_seq(word))

print(time.time() - old_time)
