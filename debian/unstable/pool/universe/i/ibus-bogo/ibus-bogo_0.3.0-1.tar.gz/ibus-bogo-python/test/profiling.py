import sys
import os.path
sys.path.append(
    os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))
sys.path.append(
    os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir, "ibus_engine")))


from bogo.bogo import *
from base_config import BaseConfig
from bogo.mark import Mark
from bogo.accent import Accent
from gen_key_sequences import gen_key_sequences


c = BaseConfig("/tmp/ibus-bogo.json")
c_non_vn = BaseConfig("/tmp/ibus-bogo-non-vn.json")
c_non_vn["skip-non-vietnamese"] = True


def process_seq(seq, config=c):
    string = ""
    raw = string
    for i in seq:
        string, raw = process_key(string,
                                  i,
                                  fallback_sequence=raw,
                                  config=config)
    return string


with open("vi-DauCu.dic") as dictionary:
    for word in dictionary.read().splitlines():
        word = word.rstrip()
        for sequence in gen_key_sequences(word):
            process_seq(sequence)
