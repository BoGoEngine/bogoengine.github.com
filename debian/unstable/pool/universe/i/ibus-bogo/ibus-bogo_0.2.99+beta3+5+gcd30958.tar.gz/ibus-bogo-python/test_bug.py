import bogo

bogo.process_key('ơ', '[', '[')
