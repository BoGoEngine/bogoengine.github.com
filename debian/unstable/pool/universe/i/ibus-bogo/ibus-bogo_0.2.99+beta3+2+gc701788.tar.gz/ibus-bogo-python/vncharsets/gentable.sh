#!/bin/sh
 
convertibles=('À' 'Á' 'Ả' 'Ã' 'Ạ' 'Ằ' 'Ắ' 'Ẳ' 'Ẵ' 'Ặ' 'Ă' 'Ầ' 'Ấ' 'Ẩ' 'Ẫ' 'Ậ' 'Â' 'È' 'É' 'Ẻ' 'Ẽ' 'Ẹ' 'Ề' 'Ế' 'Ể' 'Ễ' 'Ệ' 'Ê' 'Ì' 'Í' 'Ỉ' 'Ĩ' 'Ị' 'Ò' 'Ó' 'Ỏ' 'Õ' 'Ọ' 'Ồ' 'Ố' 'Ổ' 'Ỗ' 'Ộ' 'Ô' 'Ờ' 'Ớ' 'Ở' 'Ỡ' 'Ợ' 'Ơ' 'Ù' 'Ú' 'Ủ' 'Ũ' 'Ụ' 'Ừ' 'Ứ' 'Ử' 'Ữ' 'Ự' 'Ư' 'Ỳ' 'Ý' 'Ỷ' 'Ỹ' 'Ỵ' 'Đ' 'à' 'á' 'ả' 'ã' 'ạ' 'ằ' 'ắ' 'ẳ' 'ẵ' 'ặ' 'ă' 'ầ' 'ấ' 'ẩ' 'ẫ' 'ậ' 'â' 'è' 'é' 'ẻ' 'ẽ' 'ẹ' 'ề' 'ế' 'ể' 'ễ' 'ệ' 'ê' 'ì' 'í' 'ỉ' 'ĩ' 'ị' 'ò' 'ó' 'ỏ' 'õ' 'ọ' 'ồ' 'ố' 'ổ' 'ỗ' 'ộ' 'ô' 'ờ' 'ớ' 'ở' 'ỡ' 'ợ' 'ơ' 'ù' 'ú' 'ủ' 'ũ' 'ụ' 'ừ' 'ứ' 'ử' 'ữ' 'ự' 'ư' 'ỳ' 'ý' 'ỷ' 'ỹ' 'ỵ' 'đ')
 
#Usage: convertTo charsetName id
function convertTo() {
printf "${convertibles[$2]}" | ./uvconv -f UTF-8 -t $1 | hexdump -e '1/1 "%02x"'
}
 
#Usage: makeTable charsetName
#Example: makeTable "TCVN3" > charset.TCVN3
function makeTable() {
i=1
while [ $i -le 134 ]
do
# printf "charsetTable['%s'][%s]=%s" $1 $i `convertTo $1 $i`
printf "0x%s\t0x%s  # %s" `convertTo $1 $i` `echo -n ${convertibles[$i]} | iconv -f UTF-8 -t UTF-16BE | hexdump -e '1/1 "%02x"'` ${convertibles[$i]}
let i++
echo
done
}
#All charsets supported by uvconv
#mkdir charset-data
#for charset in BKHCM1 BKHCM2 ISC NCR-DEC NCR-HEX TCVN3 UNI-COMP UNICODE UVIQR VIETWARE-F VIETWARE-X VIQR VISCII VNI-MAC VNI-WIN VPS WINCP-1258
for charset in VNI
do
makeTable $charset > charset-data/$charset.txt
#echo `echo -n 'a' | ./uvconv -f UTF-8 -t $charset`
done
