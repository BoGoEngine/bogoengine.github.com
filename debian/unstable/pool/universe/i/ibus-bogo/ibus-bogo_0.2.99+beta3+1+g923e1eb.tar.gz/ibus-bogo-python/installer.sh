#!/bin/sh

if [ "$(id -u)" -ne 0 ]; then
	echo >&1 "ERROR: This command can only be used by root."
	exit 1
fi

echo "Writing apt source entries..."
# echo "deb http://ngochin.com/repo/ibus-bogo-unstable/ unstable universe" >> /etc/apt/sources.list.d/ibus-bogo-unstable.list
# echo "deb-src http://ngochin.com/repo/ibus-bogo-unstable/ unstable universe" >> /etc/apt/sources.list.d/ibus-bogo-unstable.list
echo "deb http://localhost:8000 unstable universe
deb-src http://localhost:8000 unstable universe" > /etc/apt/sources.list.d/ibus-bogo-unstable.list

echo "Adding our signing key..."
apt-key adv --keyserver keyserver.ubuntu.com --recv-keys C0DAAD97

echo "Updating the repository..."
apt-get update 

echo "Installing ibus-bogo..."
apt-get install ibus-bogo
