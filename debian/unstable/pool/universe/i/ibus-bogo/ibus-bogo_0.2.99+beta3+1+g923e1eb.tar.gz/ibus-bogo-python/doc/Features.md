Các tính năng nổi bật của bộ gõ:
- Không dùng pre-edit. Gõ đến đâu, tiếng Việt hiện ra đến đấy
  không cần ấn Control hay phím cách để commit. **DONE**

- Trật tự phím dấu thanh tự do. Bạn có thể gõ "tuyener" hay
  "tuyeenr" hay "tuyeren" đều có thể ra được chữ "tuyển". **DONE**

- Gõ nhanh "ươ". Bạn có thể gõ "uow" là có thể ra "ươ" mà không
  cần phải gõ "uwow". **DONE**

- Các tính năng bổ sung TELEX thông dụng trong Unikey như **DONE**
  + ][ -> ươ
  + }{ -> ƯƠ
  + w/W -> ư/Ư

- Hỗ trợ gõ các từ không phải tiếng Việt trong văn bản tiếng Việt.
  Khi bộ gõ nhận ra từ đang gõ không phải tiếng Việt thì sẽ tự động
  chuyển về chế độ ban đầu của bàn phím và hiện từ đang gõ được cố gắng
  đặt dấu thanh ở bên dưới nếu người dùng muốn thay đổi ý định. **DONE**

- Hủy dấu bằng cách lặp lại phím dấu thanh. VD: toans -> toán + s -> toans.
  Chữ cái có dấu cần hủy không nhất thiết phải đứng sát con trỏ. **DONE**

- Hủy dấu thanh gần nhất bằng phím "z" (TELEX) hoặc "0" (VNI). **TODO**

- Định nghĩa kiểu gõ của riêng người dùng. **DONE**

- Gõ tắt. **TODO**

- Gõ tiếng Việt không hiển thị dấu cách. Bạn có thể gõ bình thường (vẫn
  dùng dấu cách để ngăn cách từ) nhưng kết quả hiện ra trên màn hình
  sẽ là như thế này: gõtiếngviệtkhôngcầndùngdấucách. Tính năng này tiện
  lợi khi truy cập các trang web có tên miền tiếng Việt như:
  <http://tênmiềntiếngviệt.vn>.
  **PARTIAL** (chưa xử lý được trường hợp dấu của từ sau bị trùng với từ trước -> undo)

- Nhận diện động tác di chuột. Đây là một lỗi của IBus, ảnh hưởng đến nhiều người.
  Khi đang gõ dở mà ấn chuột vào một chỗ khác trong văn bản thì bộ
  gõ không biết là con trỏ đã di chuyển và vẫn tiếp tục xử lý gây nên
  lỗi văn bản nhảy linh tinh. **TODO**

- Tiếp tục quay lại gõ từ bị sai. VD: bạn gõ sai từ "lênh đênh" thành "lenh đênh".
  Bạn có thể ấn nút trái di chuyển con trỏ về sau chữ "e" và gõ thêm
  dấu thành "ê". **DRAFT**

- Tự động gợi ý phương án đúng cho từ sai chính tả tương tự như chức năng
  gõ từ không phải tiếng Việt. **DRAFT**
