from .bogo import process_key, default_config
